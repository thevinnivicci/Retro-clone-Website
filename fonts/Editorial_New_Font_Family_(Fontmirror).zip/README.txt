To learn more about the font family and its license, visit https://www.fontmirror.com/editorial-new

License: Free for personal use.
This is a preview font for testing, you can buy its full version at https://pangrampangram.com/products/editorial-new.